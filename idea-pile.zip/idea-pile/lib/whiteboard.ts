
class whiteboard<T> {
//    objects: Map<number, data<T>>;
//    owner_id: string; 
//    created: Date;
//    chrono_array: Array<string> = [];

//    constructor(owner_id: string){
//        this.objects = new Map<number, data<T>>;
//        this.owner_id = owner_id;
//        this.created = new Date();
//    }

    init_from_db(){
        
    }
}