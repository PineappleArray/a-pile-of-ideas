var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/whiteboards/route.js")
R.c("server/chunks/[root-of-the-server]__09c0f565._.js")
R.c("server/chunks/[root-of-the-server]__b6bc54de._.js")
R.m(59639)
R.m(84656)
module.exports=R.m(84656).exports
