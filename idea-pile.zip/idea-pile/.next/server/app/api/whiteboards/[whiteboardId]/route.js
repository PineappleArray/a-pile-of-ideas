var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/whiteboards/[whiteboardId]/route.js")
R.c("server/chunks/[root-of-the-server]__db25d702._.js")
R.c("server/chunks/[root-of-the-server]__b6bc54de._.js")
R.m(28951)
R.m(85421)
module.exports=R.m(85421).exports
