var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/whiteboards/user/[userId]/route.js")
R.c("server/chunks/[root-of-the-server]__5fad6a0f._.js")
R.c("server/chunks/[root-of-the-server]__b6bc54de._.js")
R.m(50662)
R.m(60399)
module.exports=R.m(60399).exports
