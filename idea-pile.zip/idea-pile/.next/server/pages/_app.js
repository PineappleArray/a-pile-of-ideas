var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__fdefc251._.js")
R.m(6555)
module.exports=R.m(6555).exports
