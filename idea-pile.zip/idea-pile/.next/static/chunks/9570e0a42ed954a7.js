__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/d917e9f78b34f409.js",
  "static/chunks/turbopack-d4f4a02e3e50626a.js"
])
