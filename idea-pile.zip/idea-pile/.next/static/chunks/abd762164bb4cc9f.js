__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/d917e9f78b34f409.js",
  "static/chunks/turbopack-65569451219fa2d3.js"
])
