# Idea-Pile
A full stack website for piling ideas

https://docs.google.com/document/d/1ViRGjKvU985wbKTCQTqLsehkfaE7ocBXijBzGKh-Wnk/edit?usp=sharing
A google docs full of my thought process and very disorganized planning
